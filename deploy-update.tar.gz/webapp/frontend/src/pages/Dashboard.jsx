import { useState, useEffect } from "react";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell, ComposedChart,
} from "recharts";
import { api, fmt$ } from "../lib/api";
import { CHART_COLORS as COLORS, TOOLTIP_STYLE } from "../lib/constants";

const RANGES = [
  { label: "30D", days: 30 },
  { label: "90D", days: 90 },
  { label: "6M", days: 180 },
  { label: "1Y", days: 365 },
];

// Color map for the color sales chart
const COLOR_MAP = {
  Orange: "#E87830",
  Blue: "#3E658C",
  Green: "#2ECFAA",
  Red: "#D03030",
  Grey: "#94a3b8",
  White: "#e2e8f0",
  Black: "#1e293b",
  Pink: "#ec4899",
  Purple: "#8B5CF6",
  Yellow: "#F5B731",
  Ombre: "#7BAED0",
  Other: "#8892b0",
};

// Moving average helper
function movingAvg(data, key, window) {
  return data.map((_, i) => {
    const start = Math.max(0, i - window + 1);
    const slice = data.slice(start, i + 1);
    const sum = slice.reduce((s, d) => s + (d[key] || 0), 0);
    return Math.round(sum / slice.length);
  });
}

const COMP_VIEWS = [
  { key: "realtime", label: "Today / WTD / MTD / YTD" },
  { key: "weekly", label: "Weekly Rollups" },
  { key: "monthly", label: "Monthly Rollups" },
  { key: "yearly", label: "Year-over-Year" },
  { key: "monthly2026", label: new Date().getFullYear() + " by Month" },
];

export default function Dashboard() {
  const [days, setDays] = useState(90);
  const [summary, setSummary] = useState(null);
  const [daily, setDaily] = useState([]);
  const [pnl, setPnl] = useState(null);
  const [comparison, setComparison] = useState([]);
  const [compView, setCompView] = useState("realtime");
  const [compLoading, setCompLoading] = useState(false);
  const [monthlyYoY, setMonthlyYoY] = useState({ years: [], data: [] });
  const [colorData, setColorData] = useState([]);
  const [loading, setLoading] = useState(true);

  // Load main dashboard data — each call independent so one failure doesn't kill all charts
  useEffect(() => {
    setLoading(true);
    const safe = (p, fallback) => p.catch(e => { console.error("Dashboard fetch error:", e); return fallback; });
    Promise.all([
      safe(api.summary(days), null),
      safe(api.daily(days, days <= 90 ? "daily" : "weekly"), { data: [] }),
      safe(api.pnl(days), null),
      safe(api.comparison(compView), { periods: [] }),
      safe(api.monthlyYoY(), { years: [], data: [] }),
      safe(api.colorMix(days), { colors: [] }),
    ]).then(([s, d, p, comp, yoy, colors]) => {
      if (s) setSummary(s);
      setDaily(d?.data || []);
      if (p) setPnl(p);
      setComparison(comp?.periods || []);
      setMonthlyYoY(yoy || { years: [], data: [] });
      setColorData(colors?.colors || []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [days]);

  // Load comparison data when view changes
  useEffect(() => {
    setCompLoading(true);
    api.comparison(compView).then(comp => {
      setComparison(comp.periods || []);
      setCompLoading(false);
    }).catch(() => setCompLoading(false));
  }, [compView]);

  if (loading) {
    return <div className="loading"><div className="spinner" /> Loading dashboard...</div>;
  }

  // Build chart data with moving averages
  const dailyRaw = daily;
  const ma7 = movingAvg(dailyRaw, "revenue", 7);
  const ma30 = movingAvg(dailyRaw, "revenue", 30);
  const dailyWithMA = dailyRaw.map((d, i) => ({
    ...d,
    ma7: ma7[i],
    ma30: ma30[i],
  }));

  // Monthly YoY chart data
  const yoyData = monthlyYoY.data || [];
  const yoyYears = monthlyYoY.years || [];
  const yoyColors = { "2024": "#94a3b8", "2025": "#3E658C", "2026": "#2ECFAA" };

  return (
    <>
      <div className="page-header">
        <h1>Dashboard</h1>
        <p>Amazon FBA performance overview</p>
      </div>

      {/* ── Period Comparison Table ──────────────────────── */}
      <div className="table-card comp-table-card">
        <h3>Performance Snapshot</h3>
        <div className="comp-tabs">
          {COMP_VIEWS.map(v => (
            <button
              key={v.key}
              className={`comp-tab ${compView === v.key ? "active" : ""}`}
              onClick={() => setCompView(v.key)}
            >
              {v.label}
            </button>
          ))}
        </div>
        {compLoading ? (
          <div style={{ padding: 24, textAlign: "center", color: "var(--muted)" }}>Loading...</div>
        ) : comparison.length > 0 ? (
          <div style={{ overflowX: "auto" }}>
            <table className="comp-table">
              <thead>
                <tr>
                  <th>Metric</th>
                  {comparison.map(c => (
                    <th key={c.label}>
                      {c.label}
                      {c.sub && <div style={{ fontSize: 10, fontWeight: 400, opacity: 0.7 }}>{c.sub}</div>}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <CompRow label="Revenue" values={comparison} fmt={c => fmt$(c.revenue)} chg={c => c.revChg} cls="revenue-row" />
                <CompRow label="Units Sold" values={comparison} fmt={c => c.units.toLocaleString()} chg={c => c.unitChg} />
                <CompRow label="Orders" values={comparison} fmt={c => c.orders.toLocaleString()} chg={c => c.orderChg} />
                <CompRow label="AUR" values={comparison} fmt={c => `$${c.aur.toFixed(2)}`} cls="divider-row" />
                <CompRow label="Ad Spend" values={comparison} fmt={c => fmt$(c.adSpend)} chg={c => c.adChg} />
                <CompRow label="TACOS %" values={comparison} fmt={c => `${c.tacos}%`} />
                <CompRow label="Sessions" values={comparison} fmt={c => c.sessions.toLocaleString()} chg={c => c.sessChg} />
                <CompRow label="Conv Rate" values={comparison} fmt={c => `${c.convRate}%`} cls="divider-row" />
                <CompRow label="COGS" values={comparison} fmt={c => fmt$(c.cogs || 0)} />
                <CompRow label="Amazon Fees" values={comparison} fmt={c => fmt$(c.amazonFees || 0)} />
                <CompRow label="Net Profit" values={comparison} fmt={c => fmt$(c.netProfit)} cls="profit-row" isPnl />
                <CompRow label="Margin" values={comparison} fmt={c => `${c.margin}%`} isPnl />
              </tbody>
            </table>
          </div>
        ) : (
          <div style={{ padding: 24, textAlign: "center", color: "var(--muted)" }}>No data for this period</div>
        )}
      </div>

      {/* ── Range Tabs ──────────────────────────────────── */}
      <div className="range-tabs">
        {RANGES.map(r => (
          <button
            key={r.days}
            className={`range-tab ${days === r.days ? "active" : ""}`}
            onClick={() => setDays(r.days)}
          >
            {r.label}
          </button>
        ))}
      </div>

      {/* ── KPI Cards ──────────────────────────────────── */}
      {summary && (
        <div className="kpi-grid">
          <KPI label="Revenue" value={fmt$(summary.revenue)} className="teal" />
          <KPI label="Units Sold" value={summary.units.toLocaleString()} />
          <KPI label="Orders" value={summary.orders.toLocaleString()} />
          <KPI label="Sessions" value={summary.sessions.toLocaleString()} />
          <KPI label="Avg AUR" value={`$${summary.aur.toFixed(2)}`} />
          <KPI label="Conv Rate" value={`${summary.convRate}%`} />
          <KPI label="Net Profit" value={fmt$(summary.netProfit)} className={summary.netProfit >= 0 ? "pos" : "neg"} />
          <KPI label="Margin" value={`${summary.margin}%`} className={summary.margin >= 0 ? "pos" : "neg"} />
        </div>
      )}

      {/* ── P&L Waterfall — FULL WIDTH ─────────────────── */}
      {pnl && pnl.revenue > 0 && (() => {
        const wfData = [
          { name: "Revenue", value: pnl.revenue, fill: "#2ECFAA" },
          { name: "COGS", value: -pnl.cogs, fill: "#E87830" },
          { name: "FBA Fees", value: -pnl.fbaFees, fill: "#3E658C" },
          { name: "Referral", value: -pnl.referralFees, fill: "#7BAED0" },
          { name: "Ad Spend", value: -pnl.adSpend, fill: "#F5B731" },
          { name: "Net Profit", value: pnl.netProfit, fill: pnl.netProfit >= 0 ? "#2ECFAA" : "#D03030" },
        ];
        return (
          <>
            <div className="chart-card" style={{ marginBottom: 16 }}>
              <h3>P&L Waterfall ({days <= 90 ? `${days}D` : days <= 180 ? "6M" : "1Y"})</h3>
              <p className="sub">Revenue → costs → net profit breakdown</p>
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={wfData} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(14,31,45,0.08)" />
                  <XAxis dataKey="name" tick={{ fill: "#6B8090", fontSize: 12 }} />
                  <YAxis tick={{ fill: "#6B8090", fontSize: 11 }} tickFormatter={v => `$${(Math.abs(v)/1000).toFixed(0)}k`} />
                  <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v) => [fmt$(Math.abs(v)), v < 0 ? "Cost" : "Amount"]} />
                  <Bar dataKey="value" radius={[4,4,0,0]}>
                    {wfData.map((entry, i) => (
                      <Cell key={i} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="chart-card" style={{ marginBottom: 16 }}>
              <h3>Cost Structure (% of Revenue)</h3>
              <p className="sub">Where revenue goes</p>
              <div style={{ padding: "20px 0" }}>
                {[
                  { name: "COGS", value: pnl.cogs, fill: "#E87830" },
                  { name: "Amazon Fees", value: (pnl.fbaFees || 0) + (pnl.referralFees || 0), fill: "#3E658C" },
                  { name: "Ad Spend", value: pnl.adSpend, fill: "#F5B731" },
                  { name: "Net Profit", value: pnl.netProfit, fill: pnl.netProfit >= 0 ? "#2ECFAA" : "#D03030" },
                ].map(item => {
                  const pct = pnl.revenue > 0 ? Math.round(item.value / pnl.revenue * 1000) / 10 : 0;
                  return (
                    <div key={item.name} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
                      <div style={{ width: 120, fontSize: 13, fontWeight: 600, color: "#2A3D50", flexShrink: 0 }}>{item.name}</div>
                      <div style={{ flex: 1, background: "rgba(14,31,45,0.06)", borderRadius: 6, height: 32, overflow: "hidden", position: "relative" }}>
                        <div style={{
                          width: `${Math.min(Math.abs(pct), 100)}%`,
                          height: "100%",
                          background: item.fill,
                          borderRadius: 6,
                          transition: "width 0.5s ease",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "flex-end",
                          paddingRight: 8,
                        }}>
                          {Math.abs(pct) > 8 && (
                            <span style={{ color: "#fff", fontSize: 12, fontWeight: 700 }}>{pct}%</span>
                          )}
                        </div>
                        {Math.abs(pct) <= 8 && (
                          <span style={{ position: "absolute", left: `${Math.abs(pct) + 2}%`, top: "50%", transform: "translateY(-50%)", fontSize: 12, fontWeight: 600, color: "#6B8090" }}>{pct}%</span>
                        )}
                      </div>
                      <div style={{ width: 90, textAlign: "right", fontSize: 14, fontWeight: 600, fontFamily: "'Space Grotesk', sans-serif", color: "#2A3D50" }}>{fmt$(item.value)}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        );
      })()}

      {/* ── Daily Sales + Moving Averages — FULL WIDTH ── */}
      <div className="chart-card" style={{ marginBottom: 16 }}>
        <h3>Daily Sales & Moving Averages</h3>
        <p className="sub">{days <= 90 ? "Daily" : "Weekly"} revenue with 7-day and 30-day MA</p>
        <ResponsiveContainer width="100%" height={320}>
          <ComposedChart data={dailyWithMA}>
            <defs>
              <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3E658C" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#3E658C" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(14,31,45,0.08)" />
            <XAxis dataKey="date" tick={{ fill: "#6B8090", fontSize: 11 }} tickFormatter={d => d.slice(5)} />
            <YAxis tick={{ fill: "#6B8090", fontSize: 11 }} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
            <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v) => [`$${v.toLocaleString()}`, ""]} labelFormatter={l => l} />
            <Legend />
            <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#3E658C" strokeWidth={1.5} fill="url(#revGrad)" />
            <Line type="monotone" dataKey="ma7" name="7-Day MA" stroke="#E87830" strokeWidth={2.5} strokeDasharray="5 4" dot={false} />
            <Line type="monotone" dataKey="ma30" name="30-Day MA" stroke="#2ECFAA" strokeWidth={2.5} strokeDasharray="5 4" dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* ── Traffic & Conversion Funnel — FULL WIDTH, REDESIGNED ── */}
      <div className="chart-card" style={{ marginBottom: 16 }}>
        <h3>Traffic & Conversion Funnel</h3>
        <p className="sub">Sessions background · Orders & Units bars · Conversion % overlay</p>
        <ResponsiveContainer width="100%" height={380}>
          <ComposedChart data={dailyRaw} margin={{ top: 10, right: 20, bottom: 10, left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(14,31,45,0.08)" />
            <XAxis dataKey="date" tick={{ fill: "#6B8090", fontSize: 11 }} tickFormatter={d => d.slice(5)} />
            {/* Left Y axis: Sessions (background scale) */}
            <YAxis
              yAxisId="sessions"
              tick={{ fill: "#94a3b8", fontSize: 10 }}
              tickFormatter={v => v.toLocaleString()}
              label={{ value: "Sessions", angle: -90, position: "insideLeft", fill: "#94a3b8", fontSize: 10, dx: -5 }}
            />
            {/* Inner Left Y: Orders/Units (smaller scale, auto) */}
            <YAxis
              yAxisId="units"
              tick={{ fill: "#2A3D50", fontSize: 11, fontWeight: 600 }}
              orientation="left"
              hide={true}
            />
            {/* Right Y axis: Conversion % */}
            <YAxis
              yAxisId="conv"
              orientation="right"
              tick={{ fill: "#F5B731", fontSize: 11, fontWeight: 600 }}
              tickFormatter={v => `${v}%`}
              domain={[0, 'auto']}
              label={{ value: "Conv %", angle: 90, position: "insideRight", fill: "#F5B731", fontSize: 10, dx: 5 }}
            />
            <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v, name) => {
              if (name === "Conv %") return [`${v}%`, name];
              if (name === "Sessions") return [v.toLocaleString(), name];
              return [v, name];
            }} />
            <Legend />
            {/* Sessions as faded background area */}
            <Area yAxisId="sessions" type="monotone" dataKey="sessions" name="Sessions" stroke="#94a3b8" fill="rgba(148,163,184,0.08)" strokeWidth={1} strokeDasharray="3 3" />
            {/* Orders and Units as prominent bars */}
            <Bar yAxisId="sessions" dataKey="orders" name="Orders" fill="#2ECFAA" radius={[3,3,0,0]} barSize={days <= 90 ? 10 : 5} />
            <Bar yAxisId="sessions" dataKey="units" name="Units" fill="#E87830" radius={[3,3,0,0]} barSize={days <= 90 ? 10 : 5} />
            {/* Conversion rate as bold line on right axis */}
            <Line yAxisId="conv" type="monotone" dataKey="convRate" name="Conv %" stroke="#F5B731" strokeWidth={3} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* ── Conversion Rate vs AUR — FULL WIDTH ────────── */}
      <div className="chart-card" style={{ marginBottom: 16 }}>
        <h3>Conversion Rate vs AUR</h3>
        <p className="sub">How pricing impacts conversion — conv % (left) vs AUR $ (right)</p>
        <ResponsiveContainer width="100%" height={320}>
          <ComposedChart data={dailyRaw}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(14,31,45,0.08)" />
            <XAxis dataKey="date" tick={{ fill: "#6B8090", fontSize: 11 }} tickFormatter={d => d.slice(5)} />
            <YAxis
              yAxisId="left"
              tick={{ fill: "#E87830", fontSize: 11 }}
              tickFormatter={v => `${v}%`}
              domain={['auto', 'auto']}
              label={{ value: "Conv %", angle: -90, position: "insideLeft", fill: "#E87830", fontSize: 11, dx: -5 }}
            />
            <YAxis
              yAxisId="right"
              orientation="right"
              tick={{ fill: "#3E658C", fontSize: 11 }}
              tickFormatter={v => `$${v}`}
              domain={['auto', 'auto']}
              label={{ value: "AUR $", angle: 90, position: "insideRight", fill: "#3E658C", fontSize: 11, dx: 5 }}
            />
            <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v, name) => {
              if (name === "Conv %") return [`${v}%`, name];
              if (name === "AUR ($)") return [`$${v.toFixed(2)}`, name];
              return [v, name];
            }} />
            <Legend />
            <Area yAxisId="left" type="monotone" dataKey="convRate" name="Conv %" stroke="#E87830" fill="rgba(232,120,48,0.1)" strokeWidth={2} />
            <Line yAxisId="right" type="monotone" dataKey="aur" name="AUR ($)" stroke="#3E658C" strokeWidth={2.5} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* ── Monthly Revenue Year-over-Year — FULL WIDTH ── */}
      <div className="chart-card" style={{ marginBottom: 16 }}>
        <h3>Monthly Revenue Year-over-Year</h3>
        <p className="sub">12-month comparison across {yoyYears.join(", ")}</p>
        <ResponsiveContainer width="100%" height={360}>
          <BarChart data={yoyData} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(14,31,45,0.08)" />
            <XAxis dataKey="month" tick={{ fill: "#6B8090", fontSize: 12 }} />
            <YAxis tick={{ fill: "#6B8090", fontSize: 11 }} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
            <Tooltip contentStyle={TOOLTIP_STYLE} formatter={v => [fmt$(v), "Revenue"]} />
            <Legend />
            {yoyYears.map((yr) => (
              <Bar
                key={yr}
                dataKey={String(yr)}
                name={String(yr)}
                fill={yoyColors[String(yr)] || "#8892b0"}
                radius={[3,3,0,0]}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* ── Sales by Color — FULL WIDTH ─────────────────── */}
      <div className="chart-card" style={{ marginBottom: 16 }}>
        <h3>Sales by Color</h3>
        <p className="sub">Revenue distribution by product color variant</p>
        <div style={{ padding: "16px 0" }}>
          {colorData.length > 0 ? colorData.map(item => (
            <div key={item.color} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, width: 100, flexShrink: 0 }}>
                <div style={{
                  width: 16, height: 16, borderRadius: 3,
                  background: COLOR_MAP[item.color] || "#8892b0",
                  border: item.color === "White" ? "1px solid #cbd5e1" : "none",
                }} />
                <span style={{ fontSize: 13, fontWeight: 600, color: "#2A3D50" }}>{item.color}</span>
              </div>
              <div style={{ flex: 1, background: "rgba(14,31,45,0.06)", borderRadius: 6, height: 32, overflow: "hidden", position: "relative" }}>
                <div style={{
                  width: `${Math.min(item.pct, 100)}%`,
                  height: "100%",
                  background: COLOR_MAP[item.color] || "#8892b0",
                  borderRadius: 6,
                  transition: "width 0.5s ease",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "flex-end",
                  paddingRight: 8,
                  opacity: item.color === "White" ? 0.6 : 0.85,
                }}>
                  {item.pct > 10 && (
                    <span style={{ color: item.color === "White" ? "#2A3D50" : "#fff", fontSize: 12, fontWeight: 700 }}>{item.pct}%</span>
                  )}
                </div>
                {item.pct <= 10 && (
                  <span style={{ position: "absolute", left: `${item.pct + 2}%`, top: "50%", transform: "translateY(-50%)", fontSize: 12, fontWeight: 600, color: "#6B8090" }}>{item.pct}%</span>
                )}
              </div>
              <div style={{ width: 90, textAlign: "right", fontSize: 14, fontWeight: 600, fontFamily: "'Space Grotesk', sans-serif", color: "#2A3D50" }}>{fmt$(item.revenue)}</div>
            </div>
          )) : (
            <div style={{ textAlign: "center", color: "var(--muted)", padding: 20 }}>No color data available</div>
          )}
        </div>
      </div>

      {/* ── AUR & Unit Velocity — FULL WIDTH ────────────── */}
      <div className="chart-card" style={{ marginBottom: 16 }}>
        <h3>AUR & Unit Velocity</h3>
        <p className="sub">Average unit retail vs daily unit volume</p>
        <ResponsiveContainer width="100%" height={320}>
          <ComposedChart data={dailyRaw}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(14,31,45,0.08)" />
            <XAxis dataKey="date" tick={{ fill: "#6B8090", fontSize: 11 }} tickFormatter={d => d.slice(5)} />
            <YAxis yAxisId="left" tick={{ fill: "#6B8090", fontSize: 11 }} tickFormatter={v => `$${v}`} domain={['auto', 'auto']} />
            <YAxis yAxisId="right" orientation="right" tick={{ fill: "#6B8090", fontSize: 11 }} />
            <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v, name) => {
              if (name === "AUR ($)") return [`$${v.toFixed(2)}`, name];
              return [v, name];
            }} />
            <Legend />
            <Area yAxisId="left" type="monotone" dataKey="aur" name="AUR ($)" stroke="#3E658C" fill="rgba(62,101,140,0.08)" strokeWidth={2} />
            <Line yAxisId="right" type="monotone" dataKey="units" name="Units/Day" stroke="#E87830" strokeWidth={2} strokeDasharray="4 4" dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </>
  );
}

/* ── Sub-Components ──────────────────────────────────────── */

function KPI({ label, value, className = "" }) {
  return (
    <div className="kpi-card">
      <div className="kpi-label">{label}</div>
      <div className={`kpi-value ${className}`}>{value}</div>
    </div>
  );
}

function CompRow({ label, values, fmt, chg, cls = "", isPnl = false }) {
  return (
    <tr className={cls}>
      <td className="comp-metric">{label}</td>
      {values.map((c, i) => {
        const val = fmt(c);
        const change = chg ? chg(c) : null;
        const changeClass = change > 0 ? (isPnl ? "pos" : "pos") : change < 0 ? (isPnl ? "neg" : "neg") : "";
        return (
          <td key={i}>
            <span className="comp-value">{val}</span>
            {change !== null && change !== 0 && (
              <span className={`comp-chg ${changeClass}`}>
                {change > 0 ? "▲" : "▼"} {Math.abs(change)}% YoY
              </span>
            )}
          </td>
        );
      })}
    </tr>
  );
}
